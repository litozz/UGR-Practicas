#ifndef __dibujable_
#define __dibujable_

class Dibujable{
public:
	virtual void dibujar(int grosor, bool ajedrez){}
};

#endif
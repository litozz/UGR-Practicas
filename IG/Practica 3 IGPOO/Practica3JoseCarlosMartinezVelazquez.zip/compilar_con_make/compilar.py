import os

os.system("make clean")
os.system("make")
os.system("./practica3")